migrate((app) => {
    const collection = new Collection({
        name: "pickup_requests",
        type: "base",
        listRule: null,
        viewRule: null,
        createRule: "",
        updateRule: null,
        deleteRule: null,
        fields: [
            { name: "name", type: "text", required: true, min: 1, max: 200 },
            { name: "email", type: "email", required: true },
            { name: "phone", type: "text", required: false, max: 50 },
            { name: "location", type: "text", required: true, min: 1, max: 300 },
            { name: "context", type: "text", required: false, max: 100 },
            { name: "timing", type: "text", required: false, max: 100 },
            { name: "service", type: "text", required: false, max: 100 },
            { name: "message", type: "text", required: false, max: 2000 },
        ],
    });
    app.save(collection);
}, (app) => {
    const collection = app.findCollectionByNameOrId("pickup_requests");
    app.delete(collection);
});
