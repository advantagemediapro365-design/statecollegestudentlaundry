/// <reference path="../pb_data/types.d.ts" />

onRecordAfterCreateSuccess((e) => {
  const r = e.record;

  const CONTEXT_LABELS = {
    "student-dorm": "Student living in a dorm",
    "student-apartment": "Student in an off-campus apartment",
    "student-other": "Student — other housing",
    "parent": "Parent of a student",
    "housing": "Student housing resident / manager",
    "other": "Other",
  };

  const TIMING_LABELS = {
    "morning": "Morning",
    "afternoon": "Afternoon",
    "evening": "Evening",
    "flexible": "Flexible",
  };

  const SERVICE_LABELS = {
    "one-time": "One-time wash, dry & fold pickup",
    "recurring": "Recurring laundry plan",
    "semester": "Semester laundry plan",
    "not-sure": "Not sure yet — help me decide",
  };

  const label = (map, value) => (value ? (map[value] || value) : "—");

  const name = r.get("name") || "";
  const email = r.get("email") || "";
  const phone = r.get("phone") || "";
  const location = r.get("location") || "";
  const context = label(CONTEXT_LABELS, r.get("context"));
  const timing = label(TIMING_LABELS, r.get("timing"));
  const service = label(SERVICE_LABELS, r.get("service"));
  const message = r.get("message") || "";
  const submittedAt = new Date().toISOString().replace("T", " ").slice(0, 19) + " UTC";

  const row = (labelText, value) => `
    <tr>
      <td style="padding:10px 16px;width:38%;vertical-align:top;background:#f1f7f9;border-radius:8px;font-family:'DM Sans',Arial,sans-serif;font-size:14px;font-weight:600;color:#0f3a44;">${labelText}</td>
      <td style="padding:10px 16px;vertical-align:top;font-family:'DM Sans',Arial,sans-serif;font-size:14px;color:#1f2a37;">${value || "—"}</td>
    </tr>`;

  const html = `
<!DOCTYPE html>
<html>
  <body style="margin:0;padding:0;background:#eef3f5;">
    <table width="100%" cellpadding="0" cellspacing="0" style="background:#eef3f5;padding:24px 0;">
      <tr>
        <td align="center">
          <table width="600" cellpadding="0" cellspacing="0" style="background:#ffffff;border-radius:16px;overflow:hidden;box-shadow:0 2px 8px rgba(15,58,68,0.08);">
            <tr>
              <td style="background:linear-gradient(135deg,#0c6b8a,#0f3a44);padding:24px 32px;">
                <p style="margin:0;font-family:'Sora','DM Sans',Arial,sans-serif;font-size:20px;font-weight:700;color:#ffffff;">New Pickup Request</p>
                <p style="margin:4px 0 0;font-family:'DM Sans',Arial,sans-serif;font-size:13px;color:#cfe6ee;">StateCollegeStudentLaundry.com</p>
              </td>
            </tr>
            <tr>
              <td style="padding:24px 32px 8px 32px;">
                <p style="margin:0;font-family:'DM Sans',Arial,sans-serif;font-size:15px;line-height:1.6;color:#1f2a37;">
                  A new laundry pickup request was submitted through
                  <a href="https://statecollegestudentlaundry.com" style="color:#0c6b8a;font-weight:600;text-decoration:none;">https://statecollegestudentlaundry.com</a>.
                  The customer's details are below.
                </p>
              </td>
            </tr>
            <tr>
              <td style="padding:16px 24px 24px 24px;">
                <table width="100%" cellpadding="0" cellspacing="0" style="border-collapse:separate;border-spacing:0 6px;">
                  ${row("Name", name)}
                  ${row("Email", email)}
                  ${row("Phone", phone)}
                  ${row("Pickup Location / Area", location)}
                  ${row("I am a…", context)}
                  ${row("Preferred Pickup Timing", timing)}
                  ${row("Laundry Service Needed", service)}
                  ${row("Message", message ? message.replace(/\n/g, "<br>") : "—")}
                </table>
              </td>
            </tr>
            <tr>
              <td style="padding:0 32px 24px 32px;">
                <p style="margin:0;font-family:'DM Sans',Arial,sans-serif;font-size:12px;color:#6b7785;">
                  Submitted: ${submittedAt}<br/>
                  This is an automated notification from the StateCollegeStudentLaundry.com scheduling form.
                </p>
              </td>
            </tr>
          </table>
        </td>
      </tr>
    </table>
  </body>
</html>`;

  const text = [
    "New Pickup Request — StateCollegeStudentLaundry.com",
    "",
    "A new laundry pickup request was submitted through https://statecollegestudentlaundry.com.",
    "",
    `Name: ${name || "—"}`,
    `Email: ${email || "—"}`,
    `Phone: ${phone || "—"}`,
    `Pickup Location / Area: ${location || "—"}`,
    `I am a…: ${context}`,
    `Preferred Pickup Timing: ${timing}`,
    `Laundry Service Needed: ${service}`,
    `Message: ${message || "—"}`,
    "",
    `Submitted: ${submittedAt}`,
  ].join("\n");

  const mailMessage = new MailerMessage({
    from: { name: "StateCollegeStudentLaundry.com" },
    to: [{ address: "tony@freshfoldaltoona.com" }],
    subject: `New Pickup Request — ${name || "New Submission"}`,
    html: html,
    text: text,
  });

  try {
    $app.newMailClient().send(mailMessage);
  } catch (err) {
    $app.logger().error("pickup request email failed", "to", "tony@freshfoldaltoona.com", "err", String(err));
  }

  e.next();
}, "pickup_requests");
